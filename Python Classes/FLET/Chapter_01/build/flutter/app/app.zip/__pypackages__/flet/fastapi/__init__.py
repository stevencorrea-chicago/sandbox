from flet_web.fastapi import *  # noqa: F403
